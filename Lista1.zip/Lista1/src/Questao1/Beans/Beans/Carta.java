package Questao1;

public class Carta {
    private Naipe naipe;
    private Valor valor;

    private static Carta instanciaCarta;

    public Carta(Valor valor, Naipe naipe) {
        this.naipe = naipe;
        this.valor = valor;
    }

    public Carta() {
    }

    public static Carta getInstance(){
        return instanciaCarta;
    }

    public Naipe getNaipe() {
        return naipe;
    }

    public void setNaipe(Naipe naipe) {
        this.naipe = naipe;
    }

    public Valor getValor() {
        return valor;
    }

    public void setValor(Valor valor) {
        this.valor = valor;
    }
}

