package Questao1;

public enum Naipe {
    ESPADAS,PAUS,COPAS,OUROS;
}
