package Questao1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Baralho extends Carta {
    private ArrayList<Carta> cartas;
    private Carta carta;

    private static Baralho deckPrincipal;

    public ArrayList<Carta> getCartas() {
        return cartas;
    }

    public static Baralho getInstance(){
        if(deckPrincipal == null){
            deckPrincipal = new Baralho();
        }
        return deckPrincipal;
    }

    public Carta drawCard(){
        return cartas.remove(0);
    }

    private Baralho() {
        this.cartas = new ArrayList();
        for (int i=0; i<13; i++)
        {
            Valor valor = Valor.values()[i];

            for (int j=0; j<4; j++)
            {
                Carta carta = new Carta(valor, Naipe.values()[j]);
                this.cartas.add(carta);
            }
        }

        Collections.shuffle(cartas);

        Iterator cardIterator = cartas.iterator();
        while (cardIterator.hasNext())
        {
            Carta aCard = (Carta) cardIterator.next();
            System.out.println(aCard.getValor() + " of " + aCard.getNaipe());
        }
    }

    public ArrayList<Carta> iniciarDeck(int param){
        ArrayList<Carta> dek = new ArrayList<>();
        int qte = param;
        for(int i=0;i<param;i++){
            dek = new Baralho().cartas;
        }
        return dek;
    }

    public String toString() {
        String retorno = "[ ";
        for(Carta c: cartas) {
            retorno += c.toString() + " , ";
        }
        return retorno + " ]";
    }

}
